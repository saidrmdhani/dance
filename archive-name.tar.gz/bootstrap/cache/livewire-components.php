<?php return array (
  'duration-picker' => 'App\\Http\\Livewire\\DurationPicker',
  'youtube-url' => 'App\\Http\\Livewire\\YoutubeUrl',
);