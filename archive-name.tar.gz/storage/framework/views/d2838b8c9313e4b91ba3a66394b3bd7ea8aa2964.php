<div>
    <form wire:submit.prevent="checkUrl" wire:loading.class="checking-url">
        <div class="form-group">
            <input type="url" wire:model="url" class="form-control text-center mt-3 mb-1" id="url" placeholder="أدخل رابط اليوتيوب">
            <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error">الرجاء إدخال رابط صحيح مع https</span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit" class="btn btn-primary">أكمل</button>
    </form>
    <div wire:loading>
        <img src="<?php echo e(asset('img/loading.gif')); ?>" width="32" height="32">
    </div>
    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger mt-3">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH /home/saidness/dance/resources/views/livewire/youtube-url.blade.php ENDPATH**/ ?>