<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>رقصة عتاب</title>

    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@500&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <!-- Header -->
  <header class="bg-primary py-5 mb-5">
    <div class="container h-100">
      <div class="row h-100 align-items-center">
        <div class="col-lg-12">
          <h1 class="display-4 text-white text-center mt-5 mb-2">رقصة عتاب</h1>
          <p class="lead mb-5 text-white-50 text-center text-justified">قم بإضافة مقطع صوتي إلى رقصة عتاب بكل سهولة واستمتع بالرقص!</p>
        </div>
      </div>
    </div>
  </header>

  <!-- Page Content -->
  <div class="container main-container">

    <div class="row justify-content-md-center">
      <div class="col-md-8 col-offset-2 mb-5 text-center">
          <h4>
              رابط الأغنية من اليوتيوب
          </h4>
          <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('youtube-url')->dom;
} elseif ($_instance->childHasBeenRendered('0oZonl4')) {
    $componentId = $_instance->getRenderedChildComponentId('0oZonl4');
    $componentTag = $_instance->getRenderedChildComponentTagName('0oZonl4');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0oZonl4');
} else {
    $response = \Livewire\Livewire::mount('youtube-url');
    $dom = $response->dom;
    $_instance->logRenderedChild('0oZonl4', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
      </div>
    </div>
    <!-- /.row -->

    <div class="row justify-content-md-center">
        <div class="col-md-8 col-offset-2 mb-5 text-center">
            <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('duration-picker')->dom;
} elseif ($_instance->childHasBeenRendered('uVW95rC')) {
    $componentId = $_instance->getRenderedChildComponentId('uVW95rC');
    $componentTag = $_instance->getRenderedChildComponentTagName('uVW95rC');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uVW95rC');
} else {
    $response = \Livewire\Livewire::mount('duration-picker');
    $dom = $response->dom;
    $_instance->logRenderedChild('uVW95rC', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
        </div>
      </div>
      <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">الحقوق محفوظة &copy; رقصة عتاب</p>
    </div>
    <!-- /.container -->
  </footer>
  <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH /home/saidness/dance/resources/views/home.blade.php ENDPATH**/ ?>